const numeros = [3, 6, 9, 12]
for (i=0; i<=3; i++){
    console.log(numeros[i] * 2)
}