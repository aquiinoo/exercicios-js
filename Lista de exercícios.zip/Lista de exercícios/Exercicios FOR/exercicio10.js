for(let i = 0; i <= 10; i++){
    if(i % 3 === 0 && i !== 0){
        continue
    }
    console.log(i)
}