const nomes =  ["Ana", "Bruno", "Carlos", "Diana"]

for (let i=0; i<=3; i++){
    console.log(nomes[i])
    console.log()
}