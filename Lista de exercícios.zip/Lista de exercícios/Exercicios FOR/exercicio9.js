const produtos = ["Arroz", "Feijão", "Macarrão"]
for (i= 0; i <=2; i++){
    console.log(`Item disponivel: <${produtos[i]}>`)
}