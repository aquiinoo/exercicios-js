for(let i = 1; i <=10; i++){
    if(i === 7){
        break
    }
    console.log(i)
}