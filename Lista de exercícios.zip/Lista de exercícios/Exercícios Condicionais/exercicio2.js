let idade = 18

if(idade >= 16){
    console.log("Pode votar")

    if(idade >= 18){
        console.log("Pode tirar carteira de motorista")
    }
}
else if(idade < 18){
        console.log("Menor de idade")
    }