let numero = 7

if (numero % 3 === 0) {
    console.log("É múltiplo de 3")
}
if (numero % 5 === 0) {
    console.log("É múltiplo de 5")
}
if (numero % 3 !== 0 && numero % 5 !== 0) {
    console.log("Não é múltiplo de 3 nem de 5")
}
