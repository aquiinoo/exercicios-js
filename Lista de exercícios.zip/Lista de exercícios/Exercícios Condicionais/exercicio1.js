let nota = 8

if(nota >= 7){
    console.log("Aprovado")
}
else if(nota >=4 && nota <7){
    console.log("Recuperação")
}
else if(nota <4){
    console.log("Reprovado")
}