let temperatura = 27

if (temperatura < 10) {
    console.log("Muito frio")
} else if (temperatura >= 10 && temperatura <= 17) {
    console.log("Frio")
} else if (temperatura >= 18 && temperatura <= 25) {
    console.log("Agradável")
} else {
    console.log("Quente")
}
